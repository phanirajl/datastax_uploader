#!/usr/bin/python3
import flask
from flask import Flask


app = Flask('datastax_uploader')


@app.route('/', methods=('POST',))
def hello_world():
    assert int(flask.request.content_length) < 20000, 'Too big' # FIXME: any restriction on file size?
    file = flask.request.files['file[]']
    contentstr = file.read().decode()

    return 'Uploaded file %s' % file.filename


def main(args=[]):
    app.run(debug=True)


if __name__ == '__main__':
    main()
